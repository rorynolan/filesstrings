## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----detrend-dir-thresh, eval=FALSE-------------------------------------------
#  dir_detrend_robinhood("path/to/some/dir", thresh = "Huang")

## ----detrend-dir-no-thresh, eval=FALSE----------------------------------------
#  dir_detrend_robinhood("path/to/some/dir")

