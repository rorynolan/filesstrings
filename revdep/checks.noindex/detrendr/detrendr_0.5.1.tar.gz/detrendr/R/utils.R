translate_parallel <- function(parallel) {
  checkmate::assert(checkmate::check_int(parallel),
                    checkmate::check_logical(parallel, len = 1))
  n_cores <- 1
  if (isTRUE(parallel)) {
    n_cores <- parallel::detectCores()
  } else if (is.numeric(parallel)) {
    n_cores <- parallel
    if (n_cores > parallel::detectCores()) n_cores <- parallel::detectCores()
  }
  n_cores
}

get_seed <- function() sample.int(.Machine$integer.max, 1)

#' Apply a function to each pillar of a 3-dimensional array.
#'
#' Define a 'pillar' of a 3-dimensional array as pillar `i,j` off array
#' `arr` being `arr[i, j, ]`. This function applies a specified
#' function to each pillar.
#'
#' @param arr3d A 3-dimensional array.
#' @param FUN A function which takes a vector as input and, for a given input
#'   length, outputs a vector of constant length (can be 1).
#'
#' @return If `FUN` is returning length 1 vectors, a matrix whereby
#'   `mat[i, j] = FUN(arr3d[i, j, ])`. If FUN is returning vectors of
#'   length `l > 1`, a 3-dimensional array whereby \code{arr[i, j, ] =
#'   FUN(arr3d[i, j, ])}.
#' @export
apply_on_pillars <- function(arr3d, FUN) {
  apply(arr3d, c(1, 2), FUN) %>% {
    if (length(dim(.)) == 3) {
      aperm(., c(2, 3, 1))
    } else {
      .
    }
  }
}


myarray2vec <- function (iarr, dim) {
 if (!is.matrix(iarr))
    dim(iarr) <- c(1, length(iarr))
  if (ncol(iarr) != length(dim))
    stop("Number of columns in iarr and number of dimensions differ.")
  if (any(sweep(iarr, 2, dim) > 0))
    stop("array index > dim")
  pdim <- c(1, cumprod(dim[-length(dim)]))
  iarr <- iarr - 1
  rowSums(sweep(iarr, 2, pdim, "*")) + 1
}

get_os <- function() {
  sysinf <- Sys.info()
  if (!is.null(sysinf)){
    os <- sysinf['sysname']
    if (os == 'Darwin')
      os <- "osx"
  } else { ## mystery machine
    os <- .Platform$OS.type
    if (grepl("^darwin", R.version$os))
      os <- "osx"
    if (grepl("linux-gnu", R.version$os))
      os <- "linux"
  }
  if (os == "osx") os <- "mac"
  tolower(os)
}
