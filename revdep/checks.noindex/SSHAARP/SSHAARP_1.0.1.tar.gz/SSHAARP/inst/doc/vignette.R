## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- out.width='100%', fig.align='center', fig.cap='...', , echo=FALSE-------
knitr::include_graphics("basemap_color.jpg")

## ---- out.width='100%', fig.align='center', fig.cap='...', echo=FALSE---------
knitr::include_graphics("basemap_bw.jpg")

