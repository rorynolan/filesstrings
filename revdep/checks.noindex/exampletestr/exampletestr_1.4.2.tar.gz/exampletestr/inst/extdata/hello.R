#' Say hello.
#'
#' Hello to the world.
#' @export
hello <- function() {
  print("Hello, world!")
}
