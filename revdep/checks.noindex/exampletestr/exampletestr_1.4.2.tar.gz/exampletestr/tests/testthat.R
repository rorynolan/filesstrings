library(testthat)
library(exampletestr)

test_check("exampletestr")
