#' Say goodbye.
#'
#' goodbye to the world.
#' @export
goodbye <- function() {
  print("Goodbye, world!")
}
