library(testthat)
library(ijtiff)

test_check("ijtiff")
